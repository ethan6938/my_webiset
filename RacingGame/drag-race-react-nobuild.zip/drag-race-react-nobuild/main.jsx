const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(window.DR.App));
